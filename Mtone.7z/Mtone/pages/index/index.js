var app = getApp()
var temp = []
var serviceId = "0000ffe0-0000-1000-8000-00805f9b34fb"
var characteristicId = "0000ffe1-0000-1000-8000-00805f9b34fb"

//var mc = ''
//var mac = ''
//var num = '' 
//var devices = ''
Page({
  data: {
    isbluetoothready: false,
    defaultSize: 'default',
    primarySize: 'default',
    warnSize: 'default',
    disabled: false,
    plain: false,
    loading: false,
    searchingstatus: false,
    receivedata: '',
    onreceiving: false,
    mac: '',
    num:'',
    deviceId: '',
    serviceId:'',
    characteristicId:''
  },
  onLoad: function () {
    // var str = "A13";
    // // var code = str.charCodeAt();
    // console.log(str.length)
    // console.log(str.charAt(0))
    // wx.showToast({
    //     title: '连接成功',
    //     icon: 'success',
    //     duration: 2000
    // })
    // let buffer = new ArrayBuffer(16)
    // let dataView = new DataView(buffer)
    // dataView.setUint8(1, 6)
    //console.log(dataView.getUint8(1))
  },
  switchBlueTooth: function () {
    var that = this

    that.setData({
      isbluetoothready: !that.data.isbluetoothready,
    })

    if (that.data.isbluetoothready) {
      wx.openBluetoothAdapter({
        success: function (res) {
          console.log("初始化蓝牙适配器成功")
          wx.onBluetoothAdapterStateChange(function (res) {
            console.log("蓝牙适配器状态变化", res)
            that.setData({
              isbluetoothready: res.available,
              searchingstatus: res.discovering
            })
          })
          wx.getBluetoothDevices({
            success: function (res) {
              { devices: Array[11]; errMsg: "getBluetoothDevices:ok" };
              console.log("getBluetoothDevices");
              console.log(res);
              that.setData({
                list: res.devices
              });
              console.log(that.data.list);
            },
            fail: function (res) {
              // fail
            },
            complete: function (res) {
              // complete
            }
          })
          wx.getConnectedBluetoothDevices({
            
            success: function (res) {
              { devices: Array[11]; errMsg: "getConnectedBluetoothDevices:ok" };
              console.log("getConnectedBluetoothDevices");
              console.log(res);
              that.setData({
                list: res.devices
              });
              console.log(that.data.list);
            },
            fail: function (res) {
              // fail
            },
            complete: function (res) {
              // complete
            }
          })
          wx.onBluetoothDeviceFound(function (devices) {
            allowDuplicatesKey: false,
            console.log(devices)
            temp.push(devices)
            that.setData({
              devices: temp,
              mac: devices.devices[0].deviceId,
              deviceId: devices.devices[0].deviceId,
              num: devices.devices[0].name
            })
            console.log('发现新蓝牙设备')
            console.log('蓝牙ID :'  + devices.devices[0].deviceId) 
            console.log('蓝牙名称 :'  + devices.devices[0].name)
          })
          wx.onBLECharacteristicValueChange(function (characteristic) {
            console.log('characteristic value comed:')
            let buffer = characteristic.value
            let dataView = new DataView(buffer)
            console.log("接收字节长度:" + dataView.byteLength)
            var str = ""
            for (var i = 0; i < dataView.byteLength; i++) {
              str += String.fromCharCode(dataView.getUint8(i))
            }
            str=getNowFormatDate()+"收到数据:"+str;
            that.setData({
              receivedata: that.data.receivedata + "\n" + str,
              onreceiving: true
            })
          })
        },
        fail: function (res) {
          console.log("初始化蓝牙适配器失败")
          wx.showModal({
            title: '提示',
            content: '请检查手机蓝牙是否打开',
            success: function (res) {
              that.setData({
                isbluetoothready: false,
                searchingstatus: false
              })
            }
          })
        }
      })
    } else {
      temp = []
      //先关闭设备连接
     // wx.closeBLEConnection({
        
       // deviceId: that.data.connectedDeviceId,
       //  complete: function (res) {
         // console.log(res)
          //that.setData({
            //deviceconnected: false,
           // connectedDeviceId: ""
         // })
      //  }
     // })
      wx.closeBluetoothAdapter({
        success: function (res) {
          console.log(res)
          that.setData({
            isbluetoothready: false,
            deviceconnected: false,
            devices: [],
            searchingstatus: false,
            receivedata: ''
          })
        },
        fail: function (res) {
          wx.showModal({
            title: '提示',
            content: '请检查手机蓝牙是否打开',
            success: function (res) {
              that.setData({
                isbluetoothready: false
              })
            }
          })
        }
      })
    }
  },
  searchbluetooth: function () {
    temp = []
    var that = this
    if (!that.data.searchingstatus) {
      var that = this
      wx.startBluetoothDevicesDiscovery({
        allowDuplicatesKey: false,
        success: function (res) {
          console.log("开始搜索附近蓝牙设备")
          console.log(res)
          that.setData({
            searchingstatus: !that.data.searchingstatus
          })
        }
      })
    } else {
      wx.stopBluetoothDevicesDiscovery({
        success: function (res) {
          console.log("停止蓝牙搜索")
          console.log(res)
        }
      })
    }
  },
  connectTO: function (e) {
    var that = this

    if (that.data.deviceconnected) {
      wx.notifyBLECharacteristicValueChanged({
        state: false, // 停用notify 功能
        //deviceId: temp,
        deviceId: that.data.deviceId,
       //serviceId:that.data. serviceId,
        characteristicId: that.data. characteristicId,
        success: function (res) {
          console.log("停用notify 功能")
        }
      })
      wx.closeBLEConnection({
       // deviceId: temp,
        deviceId: that.data.deviceId,
        success: function (res) {
          console.log('device services:', res.services)
          that.setData({ services: res.services });

          console.log('--------------------------------------');
          console.log('设备的id:', that.data.deviceId);
          //console.log('device设备的服务id:', that.data.serviceId);

          wx.hideLoading()
          wx.showToast({
            title: '断开成功',
            icon: 'success',
            duration: 1000
          })
          console.log("断开蓝牙设备成功")
          console.log(res)

          that.setData({
            deviceconnected: false,
            connectedDeviceId: e.currentTarget.id,
            //deviceId:[]
          })
        },
        fail: function (res) {
          console.log(res)
        },
        complete: function (res) {
          console.log(res)
        }
      })
    } else {
      wx.showLoading({
        title: '连接蓝牙设备中...',
      })
     // wx.getBLEDeviceServices({
       // success: function (res) {
         // { services: Array[11]; errMsg: "getBLEDeviceServices:ok" };
         // console.log("getBLEDeviceServices");
         // console.log(res);
         // that.setData({
         //   list: res.services
        //  });
        //  console.log(that.data.list);
      //  },
      //  fail: function (res) {
          // fail
      //  },
       // complete: function (res) {
          // complete
       // }
      //})
      
      wx.createBLEConnection({
         //deviceId:temp, 
         deviceId: that.data.deviceId,
        success: function (res) {
          console.log('device services:', res.services)
          that.setData({ services: res.services });
          
          console.log('--------------------------------------');
          console.log('设备的id:', that.data.deviceId);
         // console.log('device设备的服务id:', that.data.serviceId);

          wx.hideLoading()
          wx.showToast({
            title: '连接成功',
            icon: 'success',
            duration: 1000
          })
          console.log("连接蓝牙设备成功")
          console.log(res)
         
          that.setData({
            deviceconnected: true,
            connectedDeviceId: e.currentTarget.id,
            //deviceId:[]
          })
      },
        fail: function (res) {
          wx.hideLoading()
          wx.showToast({
            title: '连接设备失败',
            icon: 'success',
            duration: 1000
          })
          console.log("连接设备失败")
          console.log(res)
          that.setData({
            connected: false
          })
        } 
      })
      wx.stopBluetoothDevicesDiscovery({
        success: function (res) {
          console.log("停止蓝牙搜索")
          console.log(res)
        }
      })
          wx.getBLEDeviceServices({
            //deviceId: temp,
           
            deviceId: that.data.deviceId,
            //deviceId: that.data.connectedDeviceId,
            success: function (res) {
              console.log("res:", res)
            },
              fail: function (err) {
                console.log(err);
              },
          })
             // console.log('device services:', res.services)
             // console.log('设备的服务id:' + devices.devices[0].serviceId);
             // that.setData({
                //serviceId:temp,
              //  serviceId: e.currentTarget.id})
              //console.log('设备的id:', that.data.deviceId);
             // console.log('设备的服务id:' + devices.devices[0].serviceId);
              
              //console.log(that.data.list);
            
              //var count = res.services.length;
            // for (var i = 0; i < count; i++) {
                //找到相关服务 然后退出(一般以一个服务为主)
              // if (res.services[i].uuid.indexOf(write_service) >= 0) {
               //  that.getTargetCharacteric(res.services[i].uuid);
                 // break;
              // }
            // }
          
          
          wx.getBLEDeviceCharacteristics({
           deviceId: that.data.deviceId,
            serviceId: that.date.serviceId,
            success: function (res) {
              //console.log('设备特征值:' + devices.devices[0].CharacteristicsId);
              console.log('device getBLEDeviceCharacteristics:', res.characteristics);
              that.setData({
               // characteristicId:temp,
                // characteristicId: devices.devices[0].CharacteristicsId})
            }),
              that.writeBLECharacteristicValue(deviceId, that.serviceId, that.characterId_write);
              that.openNotifyService(deviceId, that.serviceId, that.characterId_read);
          },
           fail: function (err) {
             console.log(err);
           },
           complete: function () {
             console.log('complete');
            }
          })
          wx.notifyBLECharacteristicValueChanged({
            state: true, // 启用 notify 功能
            deviceId: that.data.deviceId,
            //serviceId: that.data.serviceId,
            characteristicId: that.data. characteristicId,
            success: function (res) {
              console.log("启用notify")
            }
          })

        
        
     // wx.getBLEDeviceServices({
      //  deviceId: deviceId,
      //  success: function (res) {
       //   that.getCharacter(deviceId, res.services);
       // }
    //  })
     
     // wx.getBLEDeviceCharacteristics({
      //  deviceId: deviceId,
       // serviceId: that.serviceId,
       // success: function (res) {
       //   that.writeBLECharacteristicValue(deviceId, that.serviceId, that.characterId_write);
       //   that.openNotifyService(deviceId, that.serviceId, that.characterId_read);
       // },
        //fail: function (err) {
        //  console.log(err);
       // },
       // complete: function () {
       //   console.log('complete');
       // }
     // })
    }
  },
  formSubmit: function (e) {
    console.log('form发生了submit事件，携带数据为：', e.detail.value.senddata)
    var senddata = e.detail.value.senddata;
    var that = this
    let buffer = new ArrayBuffer(senddata.length)
    let dataView = new DataView(buffer)
    for (var i = 0; i < senddata.length; i++) {
      dataView.setUint8(i, senddata.charAt(i).charCodeAt())
    }
    wx.writeBLECharacteristicValue({
      deviceId: that.data.connectedDeviceId,
      //serviceId: serviceId,
      //characteristicId: characteristicId,
      value: buffer,
      success: function (res) {
        console.log(res)
        console.log('writeBLECharacteristicValue success', res.errMsg)
      }
    })
  },
  formReset: function () {
    console.log('form发生了reset事件')
  }
})



function getNowFormatDate() {
  var date = new Date();
  var seperator1 = "-";
  var seperator2 = ":";
  var month = date.getMonth() + 1;
  var strDate = date.getDate();
  if (month >= 1 && month <= 9) {
    month = "0" + month;
  }
  if (strDate >= 0 && strDate <= 9) {
    strDate = "0" + strDate;
  }
  var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate
    + " " + date.getHours() + seperator2 + date.getMinutes()
    + seperator2 + date.getSeconds();
  return currentdate;
}